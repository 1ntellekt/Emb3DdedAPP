package com.example.emb3ddedapp.screens.mainfrag

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import com.example.emb3ddedapp.utils.REPOSITORY

class MainViewModel(application: Application) : AndroidViewModel(application) {

//    fun signOutAccount(){
//        REPOSITORY.signOut()
//    }

}