package com.example.emb3ddedapp.database.repository

import com.google.firebase.auth.FirebaseUser

interface DataRepository {

    //auth

//    fun initDatabase()
//
//    fun logInEmail(email:String,password:String,onSuccess:()->Unit,onFail:(String)->Unit)
//
//    fun singUpEmail(email:String,password:String,onSuccess:()->Unit,onFail:(String)->Unit)
//
//    fun sendVerifyEmail(user: FirebaseUser, onSuccess: () -> Unit, onFail: (String) -> Unit)
//
//    fun linkEmailToGoogle(email: String,password: String,onSuccess: () -> Unit,onFail: (String) -> Unit)
//
//    fun signUpLogInGoogle(isSignUp:Boolean,token:String,onSuccess: () -> Unit,onFail: (String) -> Unit)
//
//    fun checkUserExists(onSuccess: () -> Unit, onFail: (String) -> Unit)
//
//    fun getCurrentUser(onSuccess:()->Unit,onFail:(String)->Unit)
//
//    fun setUser(onSuccess:()->Unit,onFail:(String)->Unit)
//
//    fun editCurrentUser(onSuccess:()->Unit,onFail:(String)->Unit)
//
//    fun signOut()

}