package com.example.emb3ddedapp.screens.news.mynews

import androidx.lifecycle.ViewModel

class MyNewsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}