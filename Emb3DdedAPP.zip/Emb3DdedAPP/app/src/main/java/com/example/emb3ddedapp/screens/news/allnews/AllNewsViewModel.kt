package com.example.emb3ddedapp.screens.news.allnews

import androidx.lifecycle.ViewModel

class AllNewsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}