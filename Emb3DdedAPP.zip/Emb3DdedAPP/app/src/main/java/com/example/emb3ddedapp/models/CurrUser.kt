package com.example.emb3ddedapp.models

object CurrUser {
    var id:String = ""
    var login:String = ""
    var telNumber:String = ""
    var status:String = ""
    var tokenMsg:String = ""
    var profileUrlPhoto:String? = null
    var email:String = ""
    var password:String = ""
}