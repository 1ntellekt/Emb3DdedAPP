package com.example.emb3ddedapp.screens.friends

import androidx.lifecycle.ViewModel

class FriendsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}