package com.example.emb3ddedapp.screens.profile

import androidx.lifecycle.ViewModel

class ProfileViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}