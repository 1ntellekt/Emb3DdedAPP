package com.example.emb3ddedapp.screens.orders.myorders

import androidx.lifecycle.ViewModel

class MyOrdersViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}