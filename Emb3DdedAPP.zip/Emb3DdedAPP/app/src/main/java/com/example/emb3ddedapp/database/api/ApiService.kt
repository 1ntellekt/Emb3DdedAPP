package com.example.emb3ddedapp.database.api

interface ApiService {
}