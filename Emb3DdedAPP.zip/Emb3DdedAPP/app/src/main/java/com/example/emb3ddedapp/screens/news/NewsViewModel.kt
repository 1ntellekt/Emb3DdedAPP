package com.example.emb3ddedapp.screens.news

import androidx.lifecycle.ViewModel

class NewsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}