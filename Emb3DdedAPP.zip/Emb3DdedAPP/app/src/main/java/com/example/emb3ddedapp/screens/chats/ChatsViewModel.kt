package com.example.emb3ddedapp.screens.chats

import androidx.lifecycle.ViewModel

class ChatsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}