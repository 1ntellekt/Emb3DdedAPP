package com.example.emb3ddedapp.screens.orders

import androidx.lifecycle.ViewModel

class OrdersViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}