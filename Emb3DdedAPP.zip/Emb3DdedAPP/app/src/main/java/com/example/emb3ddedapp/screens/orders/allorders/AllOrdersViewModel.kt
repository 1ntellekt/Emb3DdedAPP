package com.example.emb3ddedapp.screens.orders.allorders

import androidx.lifecycle.ViewModel

class AllOrdersViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}